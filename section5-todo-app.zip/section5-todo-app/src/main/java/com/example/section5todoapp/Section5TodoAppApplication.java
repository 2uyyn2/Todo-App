package com.example.section5todoapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Section5TodoAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(Section5TodoAppApplication.class, args);
	}

}
