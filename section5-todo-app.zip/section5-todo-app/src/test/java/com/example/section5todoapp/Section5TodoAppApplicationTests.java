package com.example.section5todoapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Section5TodoAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
